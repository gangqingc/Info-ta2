from django.urls import path
from . import views

app_name = 'LCZ'
urlpatterns = [
    path('',views.index,name ='index'),
    path('<int:animal_id>/detail/',views.detail,name ='detail'),
    path('<int:animal_id>/results/',views.results,name = 'results'),
    path('<int:animal_id>/nourrir/',views.nourrir,name ='nourrir'),
    path('<int:animal_id>/divertir/',views.divertir,name ='divertir'),
    path('<int:animal_id>/coucher/',views.coucher,name ='coucher'),
    path('<int:animal_id>/reveiller/',views.reveiller,name ='reveiller'),
]