from django.shortcuts import render
from django.http import HttpResponseRedirect,Http404
from django.shortcuts import render,get_object_or_404
from .models import Equipement,Animal
from django.urls import reverse
from django.views import generic

# Create your views here.
def index(request):
    animal = Animal.objects.all()
    content = {'animal':animal}
    return render(request,'LCZ/index.html',content)

def detail(request,animal_id):
    try:
        animal = Animal.objects.get(pk = animal_id)
    except Animal.DoesNotExist:
        raise Http404("Animal dose not exist")
    content = {'animal':animal}
    return render(request,'LCZ/detail.html',content)
def results(request):
    pass

def nourrir(request,animal_id):
    try:
        animal = Animal.objects.get(pk = animal_id)
    except Animal.DoesNotExist:
        raise Http404("Animal does not exist")
    equipement = Equipement.objects.get(equipement_name= 'mangeoire')
    if animal.etat != 'affame':
        return render(request,'LCZ/detail.html',{
            'animal': animal,
            'error_message':"desole,cet animal n'a pas faim",
        })
    elif equipement.disponibility != 'libre':
        occupant_name=""
        occupant = equipement.cherche_occupant()
        for occu in occupant:
            occupant_name = occu+";"+occupant_name
        return render(request,'LCZ/detail.html',{
            'animal': animal,
            'error_message':"desole, le mangeoire n'est pas libre, il est occupe par: "+occupant_name,
        })
    else:
        animal.etat = 'repus'
        lieu_vacant =animal.lieu
        animal.lieu = 'mangeoire'
        equipement_occupe = Equipement.objects.get(equipement_name=lieu_vacant)
        if equipement_occupe.equipement_name != "litiere":
            equipement_occupe.disponibility = "libre"
            equipement_occupe.save()
        equipement.disponibility = "occupe"
        equipement.save()
        animal.save()
        return render(request,'LCZ/detail.html',{
            'animal':animal,
            'success':"vous avez resussi a nourrir : "+animal.animal_name,
        })

def divertir(request,animal_id):
    try:
        animal = Animal.objects.get(pk = animal_id)
    except Animal.DoesNotExist:
        raise Http404("Animal does not exist")
    try:
        equipement = Equipement.objects.get(equipement_name="roue")
    except Equipement.DoesNotExist:
        raise Http404("roue does not exist")

    if animal.etat != 'repus':
        return render(request,'LCZ/detail.html',{
            'animal': animal,
            'error_message':"desole, "+animal.animal_name+",  n'est pas en etat de faire du sport",
        })
    elif equipement.disponibility != 'libre':
        occupant_name=""
        occupant = equipement.cherche_occupant()
        for occu in occupant:
            occupant_name = occu+";"+occupant_name
        return render(request,'LCZ/detail.html',{
            'animal': animal,
            'error_message':"desole, le roue n'est pas libre, il est occupe par : "+occupant_name,
        })
    else:
        animal.etat = 'fatigue'
        #modele.change_état(id_animal, 'repus')
        lieu_vacant =animal.lieu
        animal.lieu = 'roue'
        equipement_occupe = Equipement.objects.get(equipement_name=lieu_vacant)
        if equipement_occupe.equipement_name != "litiere":
            equipement_occupe.disponibility = "libre"
            equipement_occupe.save()
        equipement.disponibility = "occupe"
        equipement.save()
        animal.save()
        return render(request,'LCZ/detail.html',{
            'animal':animal,
            'success': "vous avez resussi a divertir:  " + animal.animal_name,
        })

def coucher(request,animal_id):
    try:
        animal = Animal.objects.get(pk = animal_id)
    except Animal.DoesNotExist:
        raise Http404("Animal does not exist")
    try:
        equipement = Equipement.objects.get(equipement_name="nid")
    except Equipement.DoesNotExist:
        raise Http404("nid does not exist")
    if animal.etat != 'fatigue':
        return render(request,'LCZ/detail.html',{
            'animal': animal,
            'error_message':"desole, "+animal.animal_name+",  n'est pas fatigue",
        })
    elif equipement.disponibility != 'libre':
        occupant_name=""
        occupant = equipement.cherche_occupant()
        for occu in occupant:
            occupant_name = occu+";"+occupant_name
        return render(request,'LCZ/detail.html',{
            'animal': animal,
            'error_message':"desole le nid n'est pas libre, il est occupe par : "+occupant_name,
        })
    else:
        animal.etat = 'endormi'
        #modele.change_état(id_animal, 'repus')
        lieu_vacant =animal.lieu
        animal.lieu = 'nid'
        equipement_occupe = Equipement.objects.get(equipement_name=lieu_vacant)
        if equipement_occupe.equipement_name != "litiere":
            equipement_occupe.disponibility = "libre"
            equipement_occupe.save()
        equipement.disponibility = "occupe"
        equipement.save()
        animal.save()
        return render(request,'LCZ/detail.html',{
            'animal':animal,
            'success': "vous avez resussi a coucher:  " + animal.animal_name,
        })

def reveiller(request,animal_id):
    try:
        animal = Animal.objects.get(pk = animal_id)
    except Animal.DoesNotExist:
        raise Http404("Animal does not exist")
    if animal.etat != 'endormi':
        return render(request,'LCZ/detail.html',{
            'animal': animal,
            'error_message':"desole, "+animal.animal_name+"  ne dort pas ",
        })
    else:
        animal.etat = 'affame'
        #modele.change_état(id_animal, 'repus')
        lieu_vacant =animal.lieu
        animal.lieu = 'litiere'
        equipement_occupe = Equipement.objects.get(equipement_name=lieu_vacant)
        if equipement_occupe.equipement_name != "litiere":
            equipement_occupe.disponibility = "libre"
            equipement_occupe.save()
            animal.save()
        return render(request,'LCZ/detail.html',{
            'animal':animal,
            'success': "vous avez resussi a reveiller: " + animal.animal_name,
        })









