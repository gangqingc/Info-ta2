from django.apps import AppConfig


class LczConfig(AppConfig):
    name = 'LCZ'
