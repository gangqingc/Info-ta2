from django.contrib import admin

# Register your models here.
from  .models import Animal, Equipement

admin.site.register(Animal)
admin.site.register(Equipement)
